**DISCLAIMER**

It should be noted that port scanning can be seen as, or construed as, a crime. 
You should never execute a port scanner against any website or IP address without explicit, written, permission from the owner of the server or computer that you are targeting. Port scanning is like asking to going to someone's house and checking out all of their doors and windows. There is really only reason why anyone would do this, and it is to assess securities and vulnerabilities. Thus, if you have no good reason to be testing these things, it can be assumed you are a criminal.

_Author: @[vinitshahdeo](https://github.com/vinitshahdeo/)_
